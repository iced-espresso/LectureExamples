#include <stdio.h>


main()
{
	if (3 + 5 == 8)
	{
		printf("���");
	}
	
	printf("\n");
	system("pause");
}